import socket

SERVER_IP = input("Enter Server IP: ")
PORT = 5000

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:

    client_socket.connect((SERVER_IP, PORT))

    print("\nConnected to server")
    print("--------------------------------------")

    message = client_socket.recv(4096).decode()
    print(message)

    while True:

        command = input("Remote> ")

        if command.strip() == "":
            continue

        client_socket.send(command.encode())

        response = client_socket.recv(8192).decode()

        print(response)

        if command.lower() == "exit":
            break

except ConnectionRefusedError:

    print("Connection refused.")
    print("Make sure the server is running.")

except Exception as e:

    print("Error:", e)

finally:

    client_socket.close()
    print("Disconnected from server.")

