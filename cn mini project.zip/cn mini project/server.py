import socket
import subprocess

HOST = "0.0.0.0"
PORT = 5000

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_socket.setsockopt(
    socket.SOL_SOCKET,
    socket.SO_REUSEADDR,
    1
)

server_socket.bind((HOST, PORT))
server_socket.listen(5)

print("======================================")
print(" TELNET-LIKE REMOTE COMMAND SERVER")
print("======================================")
print("Server started...")
print("Waiting for client...")

while True:

    client_socket, client_address = server_socket.accept()

    print("Client connected:", client_address)

    client_socket.send(
        b"Connected to Remote Command Server!\n"
        b"Type a command or 'exit' to disconnect.\n"
    )

    while True:

        try:
            data = client_socket.recv(4096)

            if not data:
                break

            command = data.decode().strip()

            print("Received:", command)

            if command.lower() == "exit":
                client_socket.send(b"Connection closed.\n")
                break

            try:
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=10
                )

                output = result.stdout + result.stderr

                if output == "":
                    output = "Command executed successfully.\n"

            except subprocess.TimeoutExpired:
                output = "Command timed out.\n"

            except Exception as e:
                output = "Error: " + str(e)

            client_socket.send(output.encode())

        except ConnectionResetError:
            print("Client disconnected.")
            break

    client_socket.close()

    print("Client connection closed.")
    print("Waiting for another client...")










